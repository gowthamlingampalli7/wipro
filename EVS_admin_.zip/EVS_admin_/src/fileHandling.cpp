#include <fstream>
#include <sstream>
#include "../includes/user.h"
#include "../includes/election.h"
#include "../includes/party.h"
#include "../includes/candidate.h"
#include "../includes/vote.h"
#pragma once 

void writeUserToCSV(User& user) {    
    ofstream file;
    file.open("../resources/user.csv",  ios :: app);
    if (!file.is_open()) {
        cout << "Failed to open user.csv file." << endl;
        return;
    }
    else {
        file << user.getUserId() << ",";
        file << user.getFirstName() << ",";
        file << user.getLastName() << ",";
        file << user.getDOB() << ",";
        file << user.getAge() << ",";
        file << user.getGender()<< ",";
        file << user.getAddress() << ",";
        file << user.getPhone() << ",";
        file << user.getDistrict()<< ",";
        file << user.getConstituency() << ",";
        file << user.getPassword() << ",";
        file << user.getVoterId() << ",";
        file << user.getApproval() << ",";
        file << endl;
    }
    file.close();
}
void writeElectionToCSV(Election& election) {    
    ofstream file;
    file.open("../resources/election_details.csv",  ios :: app);
    if (!file.is_open()) {
        cout << "Failed to open election_details.csv file." << endl;
        return;
    }
    else {
        file << election.getElectionName() << ",";
        file << election.getElectionDate()<< ",";
        file << election.getVotingTime() << ",";
        file << election.getElectionDistrict() << ",";
        file << election.getElectionConstituency() << ",";
        file << endl;
    }
    file.close();
}
void writePartyToCSV(Party& party) {    
    ofstream file;
    file.open("../resources/party_details.csv",  ios :: app);
    if (!file.is_open()) {
        cout << "Failed to open party_details.csv file." << endl;
        return;
    }
    else {
        file << party.getPartyName() << ",";
        file << party.getLeader()<< ",";
        file << party.getSymbol() << ",";
        file << endl;
    }
    file.close();
}
void writeCandidateToCSV(Candidate& candidate) {    
    ofstream file;
    file.open("../resources/candidates.csv",  ios :: app);
    if (!file.is_open()) {
        cout << "Failed to open candidates.csv file." << endl;
        return;
    }
    else {
        file << candidate.getCandidateId() << ",";
        file << candidate.getName() << ",";
        file << candidate.getDOB() << ",";
        file << candidate.getElectionName() << ",";
        file << candidate.getPartyName() << ",";
        file << candidate.getDistrict()<< ",";
        file << candidate.getConstituency() << ",";
        file << candidate.getAddress() << ",";
        file << candidate.getPhone() << ",";
        file << candidate.getEmail() << ",";
        file << candidate.getVotes() << ",";
        file << endl;
    }
    file.close();
}
void writeVoteToCSV(Votes& vote) {
    ofstream file;
    file.open("../resources/votes.csv",  ios :: app);
    if (!file.is_open()) {
        cout << "Failed to open votes.csv file." << endl;
        return;
    }
    else {
        file << vote.getElectionName() << ",";
        file << vote.getVoterId() << ",";
        file << endl;
    }
    file.close();
}
//read and write users
void readUsersFromCSV(vector<User>& users) {    
    fstream file;
    file.open("../resources/user.csv" , ios :: in);
    if (!file.is_open()) {
        cout << "Failed to open user.csv file." << endl;
        return;
    }
    string data;
    while(!file.eof()) {
        getline(file, data);
        User user;
        stringstream ss(data);
        string word;
        int count = 0;
        while(getline(ss, word, ',')) {
            if(count == 0) user.setUserId(stoi(word));
            if(count == 1) user.setFirstName(word);
            if(count == 2) user.setLastName(word);
            if(count == 3) user.setDOB(word);
            if(count == 4) user.setAge(stoi(word));
            if(count == 5) user.setGender(word);
            if(count == 6) user.setAddress(word);
            if(count == 7) user.setPhone(word);
            if(count == 8) user.setDistrict(word);
            if(count == 9) user.setConstituency(word);
            if(count == 10) user.setPassword(word);
            if(count == 11) user.setVoterId(word);
            if(count == 12) user.setApproval(word);
            count++;
        }
        if(count != 0) users.push_back(user);        
    }

    file.close();
}
void writeUsersToCSV(vector<User>& users) {    
    ofstream file;
    file.open("../resources/user.csv",  ios :: out);
    if (!file.is_open()) {
        cout << "Failed to open user.csv file." << endl;
        return;
    }
    for (auto& user : users) {
        file << user.getUserId() << ",";
        file << user.getFirstName() << ",";
        file << user.getLastName() << ",";
        file << user.getDOB() << ",";
        file << user.getAge() << ",";
        file << user.getGender()<< ",";
        file << user.getAddress() << ",";
        file << user.getPhone() << ",";
        file << user.getDistrict()<< ",";
        file << user.getConstituency() << ",";
        file << user.getPassword() << ",";
        file << user.getVoterId() << ",";
        file << user.getApproval() << ",";
        file << endl;
    }
    file.close();
}

//read elections from CSV
void readElectionsFromCSV(vector<Election>& elections) {    
    fstream file;
    file.open("../resources/election_details.csv" , ios :: in);
    if (!file.is_open()) {
        cout << "Failed to open election_details.csv file." << endl;
        return;
    }
    string data;
    while(!file.eof()) {
        getline(file, data);
        Election election;
        stringstream ss(data);
        string word;
        int count = 0;
        while(getline(ss, word, ',')) {
            if(count == 0) election.setElectionName(word);
            if(count == 1) election.setElectionDate(word);
            if(count == 2) election.setVotingTime(word);
            if(count == 3) election.setElectionDistrict(word);
            if(count == 4) election.setElectionConstituency(word);
            count++;
        }
        if(count != 0) elections.push_back(election);        
    }
    file.close();
}

//read parties from CSV
void readPartiesFromCSV(vector<Party>& parties) {    
    fstream file;
    file.open("../resources/party_details.csv" , ios :: in);
    if (!file.is_open()) {
        cout << "Failed to open party_details.csv file." << endl;
        return;
    }
    string data;
    while(!file.eof()) {
        getline(file, data);
        Party party;
        stringstream ss(data);
        string word;
        int count = 0;
        while(getline(ss, word, ',')) {
            if(count == 0) party.setPartyName(word);
            if(count == 1) party.setLeader(word);
            if(count == 2) party.setSymbol(word);
            count++;
        }
        if(count != 0) parties.push_back(party);        
    }
    file.close();
}

//read candidate from CSV
void readCandidatesFromCSV(vector<Candidate>& candidates) {    
    fstream file;
    file.open("../resources/candidates.csv" , ios :: in);
    if (!file.is_open()) {
        cout << "Failed to open candidates.csv file." << endl;
        return;
    }
    string data;
    while(!file.eof()) {
        getline(file, data);
        Candidate candidate;
        stringstream ss(data);
        string word;
        int count = 0;
        while(getline(ss, word, ',')) {
            if(count == 0) candidate.setCandidateId(stoi(word));
            if(count == 1) candidate.setName(word);
            if(count == 2) candidate.setDOB(word);
            if(count == 3) candidate.setElectionName(word);
            if(count == 4) candidate.setPartyName(word);
            if(count == 5) candidate.setDistrict(word);
            if(count == 6) candidate.setConstituency(word);
            if(count == 7) candidate.setAddress(word);
            if(count == 8) candidate.setPhone(word);
            if(count == 9) candidate.setEmail(word);
            if(count == 10) candidate.setVotes(stoi(word));
            count++;
        }
        if(count != 0) candidates.push_back(candidate);        
    }
    file.close();
}
void writeCandidatesToCSV(vector<Candidate>& candidates) {    
    ofstream file;
    file.open("../resources/candidates.csv",  ios :: out);
    if (!file.is_open()) {
        cout << "Failed to open candidates.csv file." << endl;
        return;
    }
    for (auto& candidate : candidates) {
        file << candidate.getCandidateId() << ",";
        file << candidate.getName() << ",";
        file << candidate.getDOB() << ",";
        file << candidate.getElectionName() << ",";
        file << candidate.getPartyName()<< ",";
        file << candidate.getDistrict()<< ",";
        file << candidate.getConstituency() << ",";
        file << candidate.getAddress() << ",";
        file << candidate.getPhone() << ",";
        file << candidate.getEmail() << ",";
        file << candidate.getVotes() << ",";
        file << endl;
    }
    file.close();
}

//read votes from CSV
void readVotesFromCSV(vector<Votes>& votes) {    
    fstream file;
    file.open("../resources/votes.csv" , ios :: in);
    if (!file.is_open()) {
        cout << "Failed to open votes.csv file." << endl;
        return;
    }
    string data;
    while(!file.eof()) {
        getline(file, data);
        Votes vote;
        stringstream ss(data);
        string word;
        int count = 0;
        while(getline(ss, word, ',')) {
            if(count == 0) vote.setElectionName(word);
            if(count == 1) vote.setVoterId(word);
            count++;
        }
        if(count != 0) votes.push_back(vote);        
    }
    file.close();
}