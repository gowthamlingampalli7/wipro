#include "../includes/user.h"

User :: User() {
    userId = 0;
    firstName = "";
    lastName = "";
    dob = "";
    age = 0;
    gender = "";
    address = "";
    phone = "";
    district = "";
    constituency = "";
    password = "";
    approval = "";
    voterId = "";
}

User :: User(int userId, string firstName, string lastName, string dob, int age, string gender, string address, string phone, string district, string constituency, string password, string approval, string voterId) {
    this->userId = userId;
    this->firstName = firstName;
    this->lastName = lastName;
    this->dob = dob;
    this->age = age;
    this->gender = gender;
    this->address = address;
    this->phone = phone;
    this->district = district;
    this->constituency = constituency;
    this->password = password;
    this->voterId = voterId;
    this->approval = approval;
}

int User :: getUserId() {
    return userId;
}

string User :: getFirstName() {
    return firstName;
}

string User :: getLastName () {
    return lastName;
}

string User :: getDOB() {
    return dob;
} 

int User :: getAge() {
    return age;
}

string User :: getGender() {
    return gender;
}

string User :: getAddress() {
    return address;
} 

string User :: getPhone() {
    return phone;
}

string User :: getDistrict() {
    return district;
}

string User :: getConstituency() {
    return constituency;
}

string User :: getPassword() {
    return password;
}

string User :: getApproval() {
    return approval;
}

string User :: getVoterId() {
    return voterId;
}

void User :: setUserId(int userId) {
    this->userId = userId;
}

void User :: setFirstName(string firstName) {
    this->firstName = firstName;
}

void User :: setLastName(string lastName) {
    this->lastName = lastName;
}

void User :: setDOB(string dob) {
    this->dob = dob;
}

void User :: setAge(int age) {
    this->age = age;
} 

void User :: setGender (string gender) {
    this->gender = gender;
}

void User :: setAddress(string address) {
    this->address= address;
}

void User :: setPhone(string phone) {
    this->phone = phone;
}

void User :: setDistrict(string district) {
    this->district = district;
}

void User :: setConstituency(string constituency) {
    this->constituency = constituency;
}

void User :: setPassword(string password) {
    this->password = password;
}

void User :: setApproval(string approval) {
    this->approval = approval;
}

void User :: setVoterId(string voterId){
    this->voterId = voterId;
}



