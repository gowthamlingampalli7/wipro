
#include "userOperation.cpp"
#include "electoralOperation.cpp"
#include "adminOperation.cpp"

using namespace std;

int main()
{
   int choice;
startHome:
   system("clear");
   cout<<"\n\n\n\n";
   cout<<"\t\t\t"<<"██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗    ████████╗ ██████╗     ███████╗██╗   ██╗███████"<<endl;
   cout<<"\t\t\t"<<"██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝    ╚══██╔══╝██╔═══██╗    ██╔════╝██║   ██║██╔════"<<endl;
   cout<<"\t\t\t"<<"██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗         ██║   ██║   ██║    █████╗  ██║   ██║███████"<<endl;
   cout<<"\t\t\t"<<"██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝         ██║   ██║   ██║    ██╔══╝  ╚██╗ ██╔╝╚════██"<<endl;
   cout<<"\t\t\t"<<"╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗       ██║   ╚██████╔╝    ███████╗ ╚████╔╝ ███████"<<endl;
   cout<<"\t\t\t"<<"╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝       ╚═╝    ╚═════╝     ╚══════╝  ╚═══╝  ╚══════╝"<<endl ;                                                                                                                 
   cout<<"\n\n\n\n\t\t\t Select one from the below \n\n\t\t\t 1.Adminstrator Login \n\t\t\t 2.Electoral Officer Login \n\t\t\t 3.Voter Login \n\t\t\t 4.Voter Registeration \n\t\t\t 5.Exit \n\n";
   cout<<"\n\n\t\t\t Enter your choice : ";
   cin>>choice;
   
   string username,password;
   char ch;
   bool voterLoggedin = false;
   bool electoralLoggedin = false;
   bool adminLoggedin = false;

   //getting creditential
   if(choice == 1 || choice == 2 || choice == 3)
   {
       cout<<"\n\n\n\t\t\tPlease Enter you ID and Password: \n";
       cout<<"\n\n\n\t\t\tEnter email  or phone: ";
       cin>>username;
       cout <<"\n\n\n\t\t\tEnter password: ";
       cin>>password;
   }

   switch(choice) {
       case 1 : adminLoggedin = adminAuth(username, password);
                if(!adminLoggedin)
                {
                   goto startHome;
                }
                cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                cin>>ch;
               break;
       
       case 2 : electoralLoggedin = electoralAuth(username, password);
                if(!electoralLoggedin)
                {
                   goto startHome;
                }
                cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                cin>>ch;
               break;
       case 3 : voterLoggedin = userAuth(username, password);
                if(!voterLoggedin)
                {
                   goto startHome;
                }
                cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                cin>>ch;
               break;
       case 4 : userRegister();
                if(!voterLoggedin)
                {
                   goto startHome;
                }
                cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                cin>>ch;
               break;
       case 5: goto ending;
               break;
       default: cout<<"\n\n\n!!!!Wrong Choice Enter valid choice.......Enter any character to conitnue!!!!";
                cin>>ch;
                goto startHome;
               break;
   }

   //admin logged in display
adminDisplay:
   if(adminLoggedin) { 
      system("clear");
      cout<<"\n\n\n\n";           
      cout<<"\t\t\t██]]]██]███████]██]]]]]]██]]]]]]]██████]]]]]]]█████]]██████]]███]]]]███]██]███]]]]██]"<<endl;
      cout<<"\t\t\t██]]]██]██]]]]]]██]]]]]]██]]]]]]██]]]]██]]]]]██]]]██]██]]]██]████]]████]██]████]]]██]"<<endl;
      cout<<"\t\t\t███████]█████]]]██]]]]]]██]]]]]]██]]]]██]]]]]███████]██]]]██]██]████]██]██]██]██]]██]"<<endl;
      cout<<"\t\t\t██]]]██]██]]]]]]██]]]]]]██]]]]]]██]]]]██]]]]]██]]]██]██]]]██]██]]██]]██]██]██]]██]██]"<<endl;
      cout<<"\t\t\t██]]]██]███████]███████]███████]]██████]]]]]]██]]]██]██████]]██]]]]]]██]██]██]]]████]"<<endl;
                                                    
      cout<<"\n\n\n\n \t\t\t Select one from the below ";
      cout<<"\n\n\t\t\t 1.  Add Election Details \n\t\t\t 2.  Add Party Details  \n\t\t\t 3.  Add Candidate details  \n\t\t\t 4.  View Voters Request for Voter ID \n\t\t\t 5.  View Election Details  \n\t\t\t 6.  View Party Details \n\t\t\t 7.  View Candidate Details \n\t\t\t 8.  View Election Results \n\t\t\t 9.  Logout  \n\t\t\t 10.  Exit \n\n";
      cout<<"\n\n\t\t\t Enter your choice : ";
      cin>>choice;
   
      switch(choice) {
          case 1 : if(addElectionDetails()) {
                      cout << "\n\n\n\t\t\tRecord Added successfully!!"<<endl;
                   }
                   else
                      cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 2 : if (addPartyDetails()) {
                      cout << "\n\n\n\t\t\tRecord Added successfully!!\n"<<endl;
                   }
                   else
                      cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 3 : if (addCandidateDetails()) {
                      cout << "\n\n\n\t\t\tRecord Added successfully!!\n"<<endl;
                   }
                   else
                      cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 4 : if (!viewVotersRequests()) {
                      cout << "\n\n\n\t\t\tNo Requests Found!!\n"<<endl;
                   }
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 5 : if(!viewElectionDetails())
                   {
                     cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   }
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 6 : if(!viewPartyDetails())
                   {
                     cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   }
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 7 : if(!viewCandidateDetails())
                   {
                     cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   }
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 8 : if(!viewelectionResults())
                   {
                     cout << "\n\n\n\t\t\t!!!!!Something went Wrong !!!!"<<endl;
                   }
                   cout<<"\n\n\n\t\t\tEnter any character to conitnue..........";
                   cin>>ch;
                   goto adminDisplay;
                  break;
          case 9 : adminLoggedin = false;
                   goto startHome;
                  break;
          case 10 : goto ending;
                  break;
          default: cout<<"\n\n\n!!!! Wrong Choice Enter valid choice.......Enter any character to conitnue!!!!";
                   cin>>ch;
                   goto adminDisplay;
                  break;
      }
   }    
  
ending:
   system("clear");
   //ending display
   cout<<"\n\n\n\n";
   cout<<"\t\t\t████████]██]]]██]]█████]]███]]]]██]██]]]██]██]]]]██]]██████]]██]]]]██]"<<endl;
   cout<<"\t\t\t]]]██]]]]██]]]██]██]]]██]████]]]██]██]]██]]]██]]██]]██]]]]██]██]]]]██]"<<endl;
   cout<<"\t\t\t]]]██]]]]███████]███████]██]██]]██]█████]]]]]████]]]██]]]]██]██]]]]██]"<<endl;
   cout<<"\t\t\t]]]██]]]]██]]]██]██]]]██]██]]██]██]██]]██]]]]]██]]]]██]]]]██]██]]]]██]"<<endl;
   cout<<"\t\t\t]]]██]]]]██]]]██]██]]]██]██]]]████]██]]]██]]]]██]]]]]██████]]]██████]]"<<endl;
   cout<<"\n\n\n\n";
   return 0;
}
