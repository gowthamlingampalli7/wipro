#include "fileHandling.cpp"
#include<cctype>

//to find day of week
string dayofweek(int d, int m, int y)
{
    string day;
	static int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
	y -= m < 3;
	int ch =  ( y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
	 switch(ch){
        case 0: day="S";
        break;
        case 1: day="M";
        break;
        case 2: day="T";
        break;
        case 3: day="W";
        break;
        case 4: day="T";
        break;
        case 5: day="F";
        break;
        case 6: day="S";
        break;
    }
    return day;
}
//voter id generater
string generateVoterId(string fname, string lname, string dob) {
    string res = "";  
    //adding first and last name char
    fname[0] = toupper(fname[0]);
    lname[0] = toupper(lname[0]);
    res = res + fname[0] + lname[0];
    
    //splitting
    stringstream ss(dob);
    string op;
    getline(ss,op,'/');
    int month = stoi(op);
    getline(ss,op,'/');
    int day = stoi(op);
    getline(ss,op,'\0');
    int year = stoi(op);

    //adding week day char
    res += dayofweek(day,month,year);

    //adding length of first and last name
    res += to_string(fname.length()) + to_string(lname.length());

    int temp=0;
    while(day>0)
    {
        temp= temp + day%10;
        day=day/10;
    }
    day=temp;
    temp=0;
    
    while(month>0)
    {
        temp= temp + month%10;
        month=month/10;
    }
    month=temp;
    temp=0;
    
    while(year>0)
    {
        temp= temp + year%10;
        year=year/10;
    }
    year=temp;
    
    //adding sum of digit of dd mm yyyy
    res= res+to_string(month)+to_string(day)+to_string(year);
    return res;
}


bool electoralAuth(string email, string password) {
    bool flag = false;
    if(email == "electoral@gmail.com" && password == "electoral123@") {
        flag = true;
        cout<<"\n\n\n\n\n\n\t\t\t Login Successfull";
    }
    else{
        char ch;
        cout<<"\n\n\n\n\n\n\t\t\t Invalid Phone or Password  :(\n"<<endl;
        cout<<"\n\n\t\t\t Enter any key to  move forword......";
        cin>>ch;
    }
    return flag;
}

bool requestVoterId(int choice) {
    vector<User> users;
    bool flag = false;
    readUsersFromCSV(users);
    for(auto user = users.begin(); user != users.end(); ++user) {
        if(user->getApproval() == "requested")
        {
            flag = true;
            cout<<"\n\n\n";
            cout<<"\n\t\t\tUser Id        : "<<user->getUserId();
            cout<<"\n\t\t\tFirst Name     : "<<user->getFirstName();
            cout<<"\n\t\t\tLast Name      : "<<user->getLastName();
            cout<<"\n\t\t\tDOB            : "<<user->getDOB();
            cout<<"\n\t\t\tAge            : "<<user->getAge();
            cout<<"\n\t\t\tGender         : "<<user->getGender();
            cout<<"\n\t\t\tUAddress       : "<<user->getAddress();
            cout<<"\n\t\t\tPhone          : "<<user->getPhone();
            cout<<"\n\t\t\tDistrict       : "<<user->getDistrict();
            cout<<"\n\t\t\tConstituency   : "<<user->getConstituency();

            if(choice == 2) {
                int ch;
                cout<<"\n\n\t\t\tSelect one from the below ";
                cout<<"\n\t\t\t1.  Accept\n\t\t\t2.  Reject \n\t\t\t3.  Skip" ;
                cout<<"\n\n\t\t\t Enter your choice : ";
                cin>>ch;
                switch(ch) {
                    case 1 : user->setVoterId(generateVoterId(user->getFirstName(), user->getLastName(), user->getDOB()));
                             user->setApproval("Accepted");
                             cout<<"\n\n\n\n\n\n\t\t\tVoter Id Generated Successfull";
                            break;
                    case 2 : user->setApproval("rejected");
                             cout<<"\n\n\n\n\n\n\t\t\tVoter Id request Rejected";
                            break;
                    case 3 : break;
                    default: cout<<"\n\n\n!!!! Wrong Choice !!!!";
                             break;
                }
            }
        }
    }
    writeUsersToCSV(users);
    return flag;
}
