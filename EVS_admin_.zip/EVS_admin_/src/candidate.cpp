#include "../includes/candidate.h"

Candidate :: Candidate() {
    candidateId = 0;
    name = "";
    dob = "";
    electionName = "";
    partyName = "";
    district = "";
    constituency = "";
    address = "";
    phone = "";
    email = "";
    votes = 0;
}

Candidate :: Candidate(int candidateId, string name, string dob, string electionName, string partyName, string district, string constituency, string address, string phone, string email, int votes) {
    this->candidateId = candidateId;
    this->name = name;
    this->dob = dob;
    this->electionName = electionName;
    this->partyName = partyName;
    this->district = district;
    this->constituency = constituency;
    this->address = address;
    this->phone = phone;
    this->email = email;
    this->votes = votes;
}

int Candidate :: getCandidateId() {
    return candidateId;
}
string Candidate :: getName() {
    return name;
}
string Candidate :: getDOB() {
    return dob;
}
string Candidate :: getElectionName() {
    return electionName;
}
string Candidate :: getPartyName() {
    return partyName;
}
string Candidate :: getDistrict() {
    return district;
}
string Candidate :: getConstituency() {
    return constituency;
}
string Candidate :: getAddress() {
    return address;
}
string Candidate :: getPhone() {
    return phone;
}
string Candidate :: getEmail() {
    return email;
}
int Candidate :: getVotes() {
    return votes;
}
void Candidate :: setCandidateId(int candidateId) {
    this->candidateId = candidateId;
}
void Candidate :: setName(string name) {
    this->name = name;
}
void Candidate :: setDOB(string dob) {
    this->dob = dob;
}
void Candidate :: setElectionName(string electionName) {
    this->electionName = electionName;
}
void Candidate :: setPartyName(string partyName) {
    this->partyName = partyName;
}
void Candidate :: setDistrict(string district) {
    this->district = district;
}
void Candidate :: setConstituency(string constituency) {
    this->constituency = constituency;
}
void Candidate :: setAddress(string address) {
    this->address = address;
}
void Candidate :: setPhone(string phone) {
    this->phone = phone;
}
void Candidate :: setEmail(string email) {
    this->email = email;
}
void Candidate :: setVotes(int votes) {
    this->votes = votes;
}