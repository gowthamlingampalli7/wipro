#include "candidate.cpp"
#include "election.cpp"
#include "party.cpp"
#include "user.cpp"
#include "vote.cpp"
#include "fileHandling.cpp"

int getCandidateIdFromFile() {
    string str;
    fstream fp,fout;
    fp.open("../resources/candidateid.csv", ios :: in | ios :: out);
    fout.open("../resources/candidateid_new.csv", ios::out);
    fp >> str;
    int id = stoi(str);
    id += 1;
    str = to_string(id);
    fout << str;
    remove("../resources/candidateid.csv");
	// renaming the updated file with the existing file name
	rename("../resources/candidateid_new.csv", "../resources/candidateid.csv");
    fp.close();
    fout.close();
    return id;
}

bool adminAuth(string email, string password) {
    bool flag = false;
    if(email == "admin" && password == "admin123@") {
        flag = true;
        cout<<"\n\n\n\n\n\n\t\t\tLogin Successfull";
    }
    else{
        char ch;
        cout<<"\n\n\n\n\n\n\t\t\t Invalid Phone or Password  :(\n"<<endl;
        cout<<"\n\n\t\t\t Enter any key to  move forword......";
        cin>>ch;
    }
    return flag;
}

bool addElectionDetails() {
    string electionName, electionDate, votingTime, electionDistrict, electionConstituency;
    system("clear");
    cout<<"\n\n\n\n\t\t\t\tENTER THE DETIALS OF ELECTION ";
    cout<<"\n\n\t\t\t Enter an Election Name:";
    cin.ignore();
    getline(cin, electionName);
    cout<<"\n\n\t\t\t Enter an Election Date :";
    getline(cin, electionDate);
    cout<<"\n\n\t\t\t Enter a Voting Time :";
    getline(cin, votingTime);
    cout<<"\n\n\t\t\t Enter an Election District :";
    getline(cin, electionDistrict);
    cout<<"\n\n\t\t\t Enter an Election Constituency :";
    getline(cin, electionConstituency);

    Election election(electionName, electionDate, votingTime, electionDistrict, electionConstituency);
    writeElectionToCSV(election);
    return true;
}

bool addPartyDetails() {
    string partyName, leader, symbol;
    system("clear");
    cout<<"\n\n\n\n\t\t\t\tENTER THE DETIALS OF ELECTION ";
    cout<<"\n\n\t\t\t Enter an Party Name:";
    cin.ignore();
    getline(cin, partyName);
    cout<<"\n\n\t\t\t Enter a Party Leader :";
    getline(cin, leader);
    cout<<"\n\n\t\t\t Enter a Party Symbol:";
    getline(cin, symbol);

    Party party(partyName, leader, symbol);
    writePartyToCSV(party);
    return true;
}

bool addCandidateDetails() {
    int candidateId,votes = 0;
    string name, dob, electionName, partyName, district, constituency, address, phone, email;
    system("clear");
    cout<<"\n\n\n\n\t\t\t\tENTER THE DETIALS OF CANDIDATE ";
    candidateId = getCandidateIdFromFile();
    cout<<"\n\n\t\t\t Enter a Candidate Name :";
    cin.ignore();
    getline(cin, name);
    cout<<"\n\n\t\t\t Enter a Candidate Date of Birth (MM/DD/YYYY) :";
    getline(cin, dob);
    cout<<"\n\n\t\t\t Enter a Election Name:";
    getline(cin, electionName);
    cout<<"\n\n\t\t\t Enter a Party Name:";
    getline(cin, partyName);
    cout<<"\n\n\t\t\t Enter a Candidate District:";
    getline(cin, district);
    cout<<"\n\n\t\t\t Enter a Candidate Constituency:";
    getline(cin, constituency);
    cout<<"\n\n\t\t\t Enter a Candidate Address :";
    getline(cin, address);
    cout<<"\n\n\t\t\t Enter a Candidate Phone :";
    getline(cin, phone);
    cout<<"\n\n\t\t\t Enter a Candidate email:";
    getline(cin, email);

    Candidate candidate(candidateId, name, dob, electionName, partyName, district, constituency, address, phone, email, votes);
    writeCandidateToCSV(candidate);
    return true;
}

bool viewVotersRequests() {
    vector<User> users;
    bool flag = false;
    readUsersFromCSV(users);
    for(auto user = users.begin(); user != users.end(); ++user) {
        if(user->getApproval() == "requested")
        {
            flag = true;
            cout<<"\n\n\n";
            cout<<"\n\t\t\tUser Id        : "<<user->getUserId();
            cout<<"\n\t\t\tFirst Name     : "<<user->getFirstName();
            cout<<"\n\t\t\tLast Name      : "<<user->getLastName();
            cout<<"\n\t\t\tDOB            : "<<user->getDOB();
            cout<<"\n\t\t\tAge            : "<<user->getAge();
            cout<<"\n\t\t\tGender         : "<<user->getGender();
            cout<<"\n\t\t\tUAddress       : "<<user->getAddress();
            cout<<"\n\t\t\tPhone          : "<<user->getPhone();
            cout<<"\n\t\t\tDistrict       : "<<user->getDistrict();
            cout<<"\n\t\t\tConstituency   : "<<user->getConstituency();
        }
    }
    return flag;
}

bool viewElectionDetails() {
    vector<Election> elections;
    bool flag = false;
    readElectionsFromCSV(elections);
    for (auto& election : elections) {
        flag = true;
        cout<<"\n\n\n";
        cout<<"\n\t\t\tElection Name         : "<<election.getElectionName();
        cout<<"\n\t\t\tElection Date         : "<<election.getElectionDate();
        cout<<"\n\t\t\tVoting Time           : "<<election.getVotingTime();
        cout<<"\n\t\t\tElection District     : "<<election.getElectionDistrict();
        cout<<"\n\t\t\tElection Constituency : "<<election.getElectionConstituency();
    }
    return flag;
}

bool viewPartyDetails() {
    vector<Party> parties;
    bool flag = false;
    readPartiesFromCSV(parties);
    for (auto& party : parties) {
        flag = true;
        cout<<"\n\n\n";
        cout<<"\n\t\t\tParty Name         : "<<party.getPartyName();
        cout<<"\n\t\t\tParty Leader       : "<<party.getLeader();
        cout<<"\n\t\t\tVParty Symbol      : "<<party.getSymbol();
    }
    return flag;
}

bool viewCandidateDetails() {
    vector<Candidate> candidates;
    bool flag = false;
    readCandidatesFromCSV(candidates);
    for (auto& candidate : candidates) {
        flag = true;
        cout<<"\n\n\n";
        cout<<"\n\t\t\tCandidate Id        : "<<candidate.getCandidateId();
        cout<<"\n\t\t\tCandidate Name      : "<<candidate.getName();
        cout<<"\n\t\t\tCandidate DOB       : "<<candidate.getDOB();
        cout<<"\n\t\t\tElection Name       : "<<candidate.getElectionName();
        cout<<"\n\t\t\tParty Name          : "<<candidate.getPartyName();
        cout<<"\n\t\t\tDistrict            : "<<candidate.getDistrict();
        cout<<"\n\t\t\tConstituency        : "<<candidate.getConstituency();
        cout<<"\n\t\t\tCandidate Address   : "<<candidate.getAddress();
        cout<<"\n\t\t\tCandidate Phone     : "<<candidate.getPhone();
        cout<<"\n\t\t\tCandidate Email     : "<<candidate.getEmail();
    }
    return flag;
}

bool viewelectionResults() {
    bool flag = false;
    vector<Candidate> candidates;
    vector<Election> elections;
    vector<Election> userElections;
    vector<Party> parties;

    readPartiesFromCSV(parties);
    readElectionsFromCSV(elections);
    readCandidatesFromCSV(candidates);

    int count = 1;
    string constituency;
    cout<<"\n\t\t\tEnter the Constituency to view the Winner of the Elections : ";
    cin.ignore();
    getline(cin,constituency);
    
    bool electionFound = false;
    for(auto& election : elections){
        if(election.getElectionConstituency() == constituency)
        {
            electionFound = true;
            cout<<"\n\n\n";
            cout<<"\n\t\t\tNumber                : "<<count++;
            cout<<"\n\t\t\tElection Name         : "<<election.getElectionName();
            cout<<"\n\t\t\tElection Date         : "<<election.getElectionDate();
            cout<<"\n\t\t\tVoting Time           : "<<election.getVotingTime();
            cout<<"\n\t\t\tElection District     : "<<election.getElectionDistrict();
            cout<<"\n\t\t\tElection Constituency : "<<election.getElectionConstituency();
            userElections.push_back(election);
        }
    }
    if(!electionFound)
    {
        cout << "\n\n\n\t\t\tNo Election is Scheduled in your Area"<<endl;
        return false;
    }
    int choice1;
    cout<<"\n\n\t\t\tEnter your choice : ";
    cin>>choice1;
    Candidate winnerCandidate;
    int max = -1;
    int count2 = 1;
    bool candidateFound = false;
    for(auto& candidate : candidates)
    {
        if(userElections[choice1-1].getElectionName() == candidate.getElectionName())
        {
            candidateFound = true;
            if(candidate.getVotes() > max)
            {
                max = candidate.getVotes();
                winnerCandidate = candidate;
            }
        }
    }
    if(!candidateFound)
    {
        cout << "\n\n\n\t\t\tNo Candidate Found"<<endl;
        return false;
    }
    else{
        flag = true;
        system("clear");
        cout << "\n\n\n\n";
        cout<<"\t\t\t██]]]]]██]██]███]]]]██]███]]]]██]███████]██████]]"<<endl;
        cout<<"\t\t\t██]]]]]██]██]████]]]██]████]]]██]██]]]]]]██]]]██]"<<endl;
        cout<<"\t\t\t██]]█]]██]██]██]██]]██]██]██]]██]█████]]]██████]]"<<endl;
        cout<<"\t\t\t██]███]██]██]██]]██]██]██]]██]██]██]]]]]]██]]]██]"<<endl;
        cout<<"\t\t\t]███]███]]██]██]]]████]██]]]████]███████]██]]]██]"<<endl;

        cout<<"\n\n\n";
        cout<<"\n\t\t\tCandidate Name      : "<< winnerCandidate.getName();
        cout<<"\n\t\t\tNumber of Votes     : "<< winnerCandidate.getVotes();
        cout<<"\n\t\t\tParty Name          : "<< winnerCandidate.getPartyName();
        for(auto& party : parties){
            if(party.getPartyName() == winnerCandidate.getPartyName())
            {
                cout<<"\n\t\t\tParty Symbol        : "<< party.getSymbol(); 
                cout<<"\n\t\t\tParty Leader        : "<< party.getLeader(); 
            }
        }
        cout<<"\n\t\t\tDistrict            : "<< winnerCandidate.getDistrict();
        cout<<"\n\t\t\tConstituency        : "<< winnerCandidate.getConstituency();
    }
    return flag;
}
