#include "../includes/user.h"
#include "../includes/vote.h"
#include "fileHandling.cpp"

int getUserIdFromFile() {
    string str;
    fstream fp,fout;
    fp.open("../resources/userid.csv", ios :: in | ios :: out);
    fout.open("../resources/userid_new.csv", ios::out);
    fp >> str;
    int id = stoi(str);
    id += 1;
    str = to_string(id);
    fout << str;
    remove("../resources/userid.csv");
	// renaming the updated file with the existing file name
	rename("../resources/userid_new.csv", "../resources/userid.csv");
    fp.close();
    fout.close();
    return id;
}

void userRegister() {
    int userId, age;
    string firstName, lastName, dob, gender, address, phone, district, constituency, password, voterId, approval;
    system("clear");
    cout<<"\n\n\n\n\t\t\t\tENTER THE DETIALS OF USER ";
    userId = getUserIdFromFile();
    cout<<"\n\n\t\t\t Enter a User First Name :";
    cin.ignore();
    getline(cin, firstName);
    cout<<"\n\n\t\t\t Enter a User Last Name :";
    getline(cin, lastName);
    cout<<"\n\n\t\t\t Enter a User Date of Birth (MM/DD/YYYY) :";
    getline(cin, dob);
    cout<<"\n\n\t\t\t Enter a User Age :";
    cin>>age;
    cin.ignore();
    cout<<"\n\n\t\t\t Enter a User Gender:";
    getline(cin, gender);
    cout<<"\n\n\t\t\t Enter a User Address :";
    getline(cin, address);
    cout<<"\n\n\t\t\t Enter a User Phone :";
    getline(cin, phone);
    cout<<"\n\n\t\t\t Enter a User District:";
    getline(cin, district);
    cout<<"\n\n\t\t\t Enter a User Constituency:";
    getline(cin, constituency);
    cout<<"\n\n\t\t\t Enter a User Password:";
    getline(cin, password);
    voterId = "";
    approval = "pending";

    User user(userId, firstName, lastName, dob, age, gender, address, phone, district, constituency, password, approval, voterId);
    writeUserToCSV(user);
    cout<<"\n\n\n\n\n\n\t\t\t Register Successfull";
}

bool userAuth(string phone, string password) {
    bool flag = false;
    vector<User> users;
    readUsersFromCSV(users);
    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == phone && user->getPassword() == password) {
            flag = true;
            cout<<"\n\n\n\n\n\n\t\t\t Login Successfull";
            break;
        }
    }
    return flag;
}

bool requestVoterId(string username, string password) {
    bool flag = false;
    system("clear");
    vector<User> users;
    readUsersFromCSV(users);
    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == username && user->getPassword() == password) {
            flag = true;
            if(user->getApproval() == "pending") {
                user->setApproval("requested");
            }
        }
    }
    writeUsersToCSV(users);
    return flag;
}

bool viewVoterId(string username, string password) {
    bool flag = false;
    system("clear");
    vector<User> users;
    readUsersFromCSV(users);
    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == username && user->getPassword() == password) {
            flag = true;
            system("clear");
            if(user->getApproval() == "pending") {
                cout<<"\n\n\n\n\n\n\t\t\t Your Not Requested for Voter Id Yet";  
            }
            else if(user->getApproval() == "requested") {
                cout<<"\n\n\n\n\n\n\t\t\t Your Requested for Voter Id but not approved by Officer";
            }
            else if(user->getApproval() == "rejected") {
                cout<<"\n\n\n\n\n\n\t\t\t Your Voter Id is Rejected by Officer";
            }
            else {
                cout<<"\n\n\n\n\n\n\t\t\t Your Voter Id : "<<user->getVoterId();
            }
            break;
        }
    }
    return flag;
}

bool viewElectionSchedule(string username, string password) {
    bool flag = false;
    system("clear");
    vector<User> users;
    vector<Election> elections;
    readUsersFromCSV(users);
    readElectionsFromCSV(elections);
    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == username && user->getPassword() == password) {
            for(auto& election : elections){
                if(user->getConstituency() == election.getElectionConstituency() && user->getDistrict() == election.getElectionDistrict()) {
                    flag = true;
                    cout<<"\n\n\n";
                    cout<<"\n\t\t\tElection Name         : "<<election.getElectionName();
                    cout<<"\n\t\t\tElection Date         : "<<election.getElectionDate();
                    cout<<"\n\t\t\tVoting Time           : "<<election.getVotingTime();
                    cout<<"\n\t\t\tElection District     : "<<election.getElectionDistrict();
                    cout<<"\n\t\t\tElection Constituency : "<<election.getElectionConstituency();
                }
            }
        }
    }
    return flag;
}

bool castVoteById(string username, string password) {
    bool flag = false;
    vector<User> users;

    vector<Candidate> candidates;
    vector<Candidate> userCandidates;

    vector<Election> elections;
    vector<Election> userElections;

    vector<Votes> votes;

    readUsersFromCSV(users);
    readElectionsFromCSV(elections);
    readCandidatesFromCSV(candidates);
    readVotesFromCSV(votes);

    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == username && user->getPassword() == password) {
            if(user->getAge() < 18) {
                break;
            }
            else if(user->getVoterId() == "")
            {
                cout << "\n\n\n\t\t\tYou Don\'t have voter Id"<<endl;
            }
            else{
                //voting code
                system("clear");
                int count = 1;
                bool electionFound = false;
                for(auto& election : elections){
                    if(election.getElectionConstituency() == user->getConstituency())
                    {
                        electionFound = true;
                        cout<<"\n\n\n";
                        cout<<"\n\t\t\tNumber                : "<<count++;
                        cout<<"\n\t\t\tElection Name         : "<<election.getElectionName();
                        cout<<"\n\t\t\tElection Date         : "<<election.getElectionDate();
                        cout<<"\n\t\t\tVoting Time           : "<<election.getVotingTime();
                        cout<<"\n\t\t\tElection District     : "<<election.getElectionDistrict();
                        cout<<"\n\t\t\tElection Constituency : "<<election.getElectionConstituency();
                        userElections.push_back(election);
                    }
                }
                if(!electionFound)
                {
                    cout << "\n\n\n\t\t\tNo Election is Schedule in your Area"<<endl;
                    return false;
                }
                int choice1;
                cout<<"\n\n\t\t\tEnter your choice : ";
                cin>>choice1;
                for(auto& vote : votes)
                {
                    if(userElections[choice1-1].getElectionName() == vote.getElectionName() && user->getVoterId() == vote.getVoterId())
                    {
                        cout<<"\n\t\t\tYou Already voted ";
                        return false;
                    }
                }
                int count2 = 1;
                bool candidateFound = false;
                for(auto& candidate : candidates)
                {
                    if(userElections[choice1-1].getElectionName() == candidate.getElectionName())
                    {
                        candidateFound = true;
                        cout<<"\n\n\n";
                        cout<<"\n\t\t\tNumber              : "<<count2++;
                        cout<<"\n\t\t\tCandidate Id        : "<<candidate.getCandidateId();
                        cout<<"\n\t\t\tCandidate Name      : "<<candidate.getName();
                        cout<<"\n\t\t\tCandidate DOB       : "<<candidate.getDOB();
                        cout<<"\n\t\t\tElection Name       : "<<candidate.getElectionName();
                        cout<<"\n\t\t\tParty Name          : "<<candidate.getPartyName();
                        cout<<"\n\t\t\tDistrict            : "<<candidate.getDistrict();
                        cout<<"\n\t\t\tConstituency        : "<<candidate.getConstituency();
                        cout<<"\n\t\t\tCandidate Address   : "<<candidate.getAddress();
                        cout<<"\n\t\t\tCandidate Phone     : "<<candidate.getPhone();
                        cout<<"\n\t\t\tCandidate Email     : "<<candidate.getEmail();
                        userCandidates.push_back(candidate);
                    }
                }
                if(!candidateFound)
                {
                    cout << "\n\n\n\t\t\tNo Candidate Found"<<endl;
                    return false;
                }
                int choice2;
                cout<<"\n\n\t\t\tEnter your choice : ";
                cin>>choice2;
                for(auto& candidate : candidates) {
                    if(userCandidates[choice2-1].getCandidateId() == candidate.getCandidateId())
                    {
                        flag = true;
                        int votes = candidate.getVotes();
                        candidate.setVotes(votes+1);
                    }
                }
                writeCandidatesToCSV(candidates);
                Votes vote;
                vote.setElectionName(userElections[choice1-1].getElectionName());
                vote.setVoterId(user->getVoterId());
                writeVoteToCSV(vote);

            }
        }
    }
    return flag;
}

bool viewElectionResults(string username, string password) {
    bool flag = false;
    vector<User> users;

    vector<Candidate> candidates;

    vector<Election> elections;
    vector<Election> userElections;
    vector<Party> parties;

    readPartiesFromCSV(parties);
    readUsersFromCSV(users);
    readElectionsFromCSV(elections);
    readCandidatesFromCSV(candidates);

    for (auto user = users.begin(); user != users.end(); ++user) {
        if (user->getPhone() == username && user->getPassword() == password) {
            int count = 1;
            bool electionFound = false;
            for(auto& election : elections){
                if(election.getElectionConstituency() == user->getConstituency())
                {
                    electionFound = true;
                    cout<<"\n\n\n";
                    cout<<"\n\t\t\tNumber                : "<<count++;
                    cout<<"\n\t\t\tElection Name         : "<<election.getElectionName();
                    cout<<"\n\t\t\tElection Date         : "<<election.getElectionDate();
                    cout<<"\n\t\t\tVoting Time           : "<<election.getVotingTime();
                    cout<<"\n\t\t\tElection District     : "<<election.getElectionDistrict();
                    cout<<"\n\t\t\tElection Constituency : "<<election.getElectionConstituency();
                    userElections.push_back(election);
                }
            }
            if(!electionFound)
            {
                cout << "\n\n\n\t\t\tNo Election is Scheduled in your Area"<<endl;
                return false;
            }
            int choice1;
            cout<<"\n\n\t\t\tEnter your choice : ";
            cin>>choice1;
            Candidate winnerCandidate;
            int max = -1;
            int count2 = 1;
            bool candidateFound = false;
            for(auto& candidate : candidates)
            {
                if(userElections[choice1-1].getElectionName() == candidate.getElectionName())
                {
                    candidateFound = true;
                    if(candidate.getVotes() > max)
                    {
                        max = candidate.getVotes();
                        winnerCandidate = candidate;
                    }
                }
            }
            if(!candidateFound)
            {
                cout << "\n\n\n\t\t\tNo Candidate Found"<<endl;
                return false;
            }
            else{
                flag = true;
                system("clear");
                cout << "\n\n\n\n";
                cout<<"\t\t\t██]]]]]██]██]███]]]]██]███]]]]██]███████]██████]]"<<endl;
                cout<<"\t\t\t██]]]]]██]██]████]]]██]████]]]██]██]]]]]]██]]]██]"<<endl;
                cout<<"\t\t\t██]]█]]██]██]██]██]]██]██]██]]██]█████]]]██████]]"<<endl;
                cout<<"\t\t\t██]███]██]██]██]]██]██]██]]██]██]██]]]]]]██]]]██]"<<endl;
                cout<<"\t\t\t]███]███]]██]██]]]████]██]]]████]███████]██]]]██]"<<endl;
                cout<<"\n\n\n";
                cout<<"\n\t\t\tCandidate Name      : "<< winnerCandidate.getName();
                cout<<"\n\t\t\tNumber of Votes     : "<< winnerCandidate.getVotes();
                cout<<"\n\t\t\tParty Name          : "<< winnerCandidate.getPartyName();
                for(auto& party : parties){
                    if(party.getPartyName() == winnerCandidate.getPartyName())
                    {
                        cout<<"\n\t\t\tParty Symbol        : "<< party.getSymbol(); 
                        cout<<"\n\t\t\tParty Leader        : "<< party.getLeader(); 
                    }
                }
                cout<<"\n\t\t\tDistrict            : "<< winnerCandidate.getDistrict();
                cout<<"\n\t\t\tConstituency        : "<< winnerCandidate.getConstituency();
            }
        }
    }
    return flag;
}
