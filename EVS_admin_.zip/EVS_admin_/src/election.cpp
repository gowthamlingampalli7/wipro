#include "../includes/election.h"

Election :: Election() {
    electionName = "";
    electionDate = "";
    votingTime = "";
    electionDistrict = "";
    electionConstituency = "";
}

Election :: Election(string electionName, string electionDate, string votingTime, string electionDistrict, string electionConstituency) {
    this->electionName = electionName;
    this->electionDate = electionDate;
    this->votingTime = votingTime;
    this->electionDistrict = electionDistrict;
    this->electionConstituency = electionConstituency;
}

string Election :: getElectionName() {
    return electionName;
}

string Election :: getElectionDate() {
    return electionDate;
}

string Election :: getVotingTime() {
    return votingTime;
}

string Election :: getElectionDistrict() {
    return electionDistrict;
}

string Election :: getElectionConstituency() {
    return electionConstituency;
}

void Election :: setElectionName(string electionName) {
    this->electionName = electionName;
}

void Election :: setElectionDate(string electionDate) {
    this->electionDate= electionDate;
}

void Election :: setVotingTime(string votingTime) {
    this->votingTime = votingTime;
}

void Election :: setElectionDistrict(string electionDistrict) {
    this->electionDistrict = electionDistrict;
}
void Election :: setElectionConstituency(string constituency) {
    this->electionConstituency= constituency;
}
