#include "../includes/vote.h"

Votes :: Votes () {
    electionName = "";
    voterId = "";
}
Votes :: Votes(string electionName, string voterId) {
    this->electionName = electionName;
    this->voterId = voterId;
}

string Votes :: getElectionName() {
    return electionName;
}
string Votes :: getVoterId() {
    return voterId;
}

void Votes :: setElectionName(string electionName) {
    this->electionName = electionName;
}
void Votes :: setVoterId(string voterId) {
    this->voterId = voterId;
}