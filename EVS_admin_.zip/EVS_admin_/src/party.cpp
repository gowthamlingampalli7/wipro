#include "../includes/party.h"

Party :: Party() {
    partyName = "";
    leader = "";
    symbol = "";
}

Party :: Party(string partyName, string leader, string symbol) {
    this->partyName = partyName;
    this->leader = leader;
    this->symbol = symbol;
}

string Party :: getPartyName() {
    return partyName;
}

string Party :: getLeader() {
    return leader;
}

string Party :: getSymbol() {
    return symbol;
}

void Party :: setPartyName(string partyName) {
    this->partyName = partyName;
}

void Party :: setLeader(string leader) {
    this->leader = leader;
}

void Party :: setSymbol(string symbol) {
    this->symbol = symbol;
}

