#include <iostream>
#include <fstream>
using namespace std;
#pragma once 

class Party {
private :
    string partyName;
    string leader;
    string symbol;
public:
    Party();
    Party(string, string, string);

    string getPartyName();
    string getLeader();
    string getSymbol();

    void setPartyName(string);
    void setLeader(string);
    void setSymbol(string);
};