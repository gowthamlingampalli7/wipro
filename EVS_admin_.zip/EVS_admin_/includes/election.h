#include <iostream>
#include <fstream>
using namespace std;
#pragma once 

class Election {
private :
    string electionName;
    string electionDate;
    string votingTime;
    string electionDistrict;
    string electionConstituency;

public :
    Election();
    Election(string, string, string, string, string);

    string getElectionName();
    string getElectionDate();
    string getVotingTime();
    string getElectionDistrict();
    string getElectionConstituency();

    void setElectionName(string);
    void setElectionDate(string);
    void setVotingTime(string);
    void setElectionDistrict(string);
    void setElectionConstituency(string);
};