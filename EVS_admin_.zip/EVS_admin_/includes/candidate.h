#include <iostream>
#include <fstream>
using namespace std;
#pragma once 

class Candidate{
private:
    int candidateId;
    string name;
    string dob;
    string electionName;
    string partyName;
    string district;
    string constituency;
    string address;
    string phone;
    string email;
    int votes;

public:
    Candidate();
    Candidate(int, string, string, string, string, string, string, string, string, string, int);

    int getCandidateId();
    string getName();
    string getDOB();
    string getElectionName();
    string getPartyName();
    string getDistrict();
    string getConstituency();
    string getAddress();
    string getPhone();
    string getEmail();
    int getVotes();

    void setCandidateId(int);
    void setName(string);
    void setDOB(string);
    void setElectionName(string);
    void setPartyName(string);
    void setDistrict(string);
    void setConstituency(string);
    void setAddress(string);
    void setPhone(string);
    void setEmail(string);
    void setVotes(int);
};