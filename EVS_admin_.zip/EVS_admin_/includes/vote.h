#include <iostream>
#include <fstream>
using namespace std;
#pragma once 

class Votes{
private:
    string electionName;
    string voterId;
public:
    Votes();
    Votes(string, string);

    string getElectionName();
    string getVoterId();

    void setElectionName(string);
    void setVoterId(string);
};