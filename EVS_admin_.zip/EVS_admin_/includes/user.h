#include <iostream>
#include <fstream>
using namespace std;
#pragma once 

class User {
private :
    int userId;
    string firstName;
    string lastName;
    string dob;
    int age;
    string gender;
    string address;
    string phone;
    string district;
    string constituency;
    string password;
    string approval;
    string voterId;

public:
    User();
    User(int, string, string, string, int, string, string, string, string, string, string, string, string);

    int getUserId();
    string getFirstName();
    string getLastName();
    string getDOB();
    int getAge();
    string getGender();
    string getAddress();
    string getPhone();
    string getDistrict();
    string getConstituency();
    string getPassword();
    string getApproval();
    string getVoterId();

    void setUserId(int);
    void setFirstName(string);
    void setLastName(string);
    void setDOB(string);
    void setAge(int);
    void setGender(string);
    void setAddress(string);
    void setPhone(string);
    void setDistrict(string);
    void setConstituency(string);
    void setPassword(string);
    void setApproval(string);
    void setVoterId(string);
 
};