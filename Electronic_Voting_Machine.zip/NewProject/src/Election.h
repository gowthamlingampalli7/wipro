class Election
{

	public:
		int es,eds,electionStatus;
		char *electionName;// = new char[20];
                char*electionDate;// = new char[20];
                char *votingTime;// = new char[15];
                char *district;// = new char[20];
                char *constituency;// = new char[20];
		//string eElectionName, eElectionDate, uElectionDate, uElectionName, uDistrict, uConstituency;
		char *resultDate;
		char *electionWinner;
		char *voterName;
		char *voterDob;
		char *voterAddress;
		char *voterMobileNo;
		void addElectionDetails();
		void viewElectionDetails();
		void deleteElectionDetails();
		void updateElectionDetails();
		void electionResult();
		void voterRequests();
};
