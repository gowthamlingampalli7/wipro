#include "Party.h"
#include<iostream>
#include<fstream>
using namespace std;
void Party :: addPartyDetails()
{
        system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                       Adding Party Details                                                  \n";
        cout << "=============================================================================================================\n";
	char *partyName = new char[20];
	char *leaderName = new char[20];
	char *partySymbol = new char[20];
	cout << "Enter Party Name : ";
	cin >> partyName;
	cout << "Enter Leader Name : ";
	cin >> leaderName;
	cout << "Enter Party Symbol : ";
	cin >> partySymbol;
	ofstream write;
	write.open("../resources/PartyData.txt",ios::app);
	if(write.is_open())
	{
		write << partyName <<"\t"<< leaderName <<"\t"<< partySymbol <<"\n";
		cout << "************************ PARTY DETAILS ADDED SUCCESSFULLY ******************************\n";
	}
	write.close();
}


void Party :: viewPartyDetails()
{
        system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                              Party Details                                                  \n";
        cout << "=============================================================================================================\n";
	char *partyName = new char[20];
        char *leaderName = new char[20];
        char *partySymbol = new char[20];
	ifstream read;
	read.open("../resources/PartyData.txt");
	if(read.is_open())
	{
		while(read >> partyName >> leaderName >> partySymbol)
		{
			cout << partyName <<"\t"<< leaderName <<"\t"<< partySymbol<<"\n";
		}
	}
	else
		cout << "Data cannot be shown\n";
	read.close();

}

void Party :: updatePartyDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                             Update Party Details                                            \n";
        cout << "=============================================================================================================\n";
	int pS=-1, partyStatus=0;
	char *ePartyName= new char[20];
	char *partyName = new char[20];
        char *leaderName = new char[20];
        char *partySymbol = new char[20];
	cout << "Enter Party Name to Update : ";
	cin >> ePartyName;
        ifstream read;
	ofstream write;
        read.open("../resources/PartyData.txt");
	//cout <<"check\n";
        if(read.is_open())
        {
		//cout<<"check\n";
                while(read >> partyName >> leaderName >> partySymbol)
                {
                        pS = strcmp(partyName, ePartyName);
			if(pS == 0)
			{
				partyStatus = 1;
				break;
			}
                }
        }
	read.close();
	//cout << "Ps="<<partyStatus<<endl;
	if(partyStatus == 1)
	{
		char *uPartyName = new char[20];
        	char *uLeaderName = new char[20];
        	char *uPartySymbol = new char[20];
		cout << "Enter Updated Party Name : ";
		cin >> uPartyName;
		cout << "Enter Updated Leader Name : ";
		cin >> uLeaderName;
		cout << "Enter Updated Party Symbol : ";
		cin >> uPartySymbol;
		read.open("../resources/PartyData.txt");
		write.open("../resources/PartyDataTemp.txt",ios::app);
		if(read.is_open())
		{
			while(read >> partyName >> leaderName >> partySymbol)
                	{       
                        	pS = strcmp(partyName,ePartyName);
                        	if(pS == 0)
                        	{
                                	write << uPartyName <<"\t"<< uLeaderName <<"\t"<< uPartySymbol <<"\n";
                        	}
				else
				{
					write << partyName <<"\t"<< leaderName <<"\t"<< partySymbol <<"\n";
				}
			}
                }
        	read.close();
		write.close();
		remove("../resources/PartyData.txt");
		rename("../resources/PartyDataTemp.txt","../resources/PartyData.txt");
		cout << "************************ PARTY DETAILS UPDATED SUCCESSFULLY ******************************\n";
	}
	else
		cout << "Party Details are not found to Update\n";

}

void Party :: deletePartyDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                          Delete Party Details                                               \n";
        cout << "=============================================================================================================\n";
	int pS=-1, partyStatus=0;
        char *ePartyName= new char[20];
	char *partyName = new char[20];
        char *leaderName = new char[20];
        char *partySymbol = new char[20];
        cout << "Enter Party Name to Delete : ";
        cin >> ePartyName;
        ifstream read;
	ofstream write;
        read.open("../resources/PartyData.txt");
        if(read.is_open())
        {       
                while(read >> partyName >> leaderName >> partySymbol)
                {       
                        pS = strcmp(partyName,ePartyName);
                        if(pS == 0)
                        {
                                partyStatus = 1;
                                break;
                        }
                }
        }
        read.close();
        if(partyStatus == 1)
        {
                read.open("../resources/PartyData.txt");
                write.open("../resources/PartyDataTemp.txt",ios::app);
                if(read.is_open())
                {       
                        while(read >> partyName >> leaderName >> partySymbol)
                        {       
                                pS = strcmp(partyName,ePartyName);
                                if(pS != 0)
				{
					write << partyName <<"\t"<< leaderName <<"\t"<< partySymbol <<"\n";
				}
			}
		}
		read.close();
		write.close();
		remove("../resources/PartyData.txt");
                rename("../resources/PartyDataTemp.txt","../resources/PartyData.txt");
		cout << "************************ PARTY DETAILS DELETED SUCCESSFULLY ******************************\n";
	}
	else
		cout << "Party Details are not available to delete\n";
	

}

