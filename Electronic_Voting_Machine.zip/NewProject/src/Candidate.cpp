#include "Candidate.h"
#include<iostream>
#include <fstream>
#include <string>
#include <cstring>
using namespace std;
void Candidate :: addCandidateDetails()
{
	system("clear");
	cout << "=============================================================================================================\n";
	cout << "					Adding Candidate Details					      \n";
	cout << "=============================================================================================================\n";
	char *candidateID = new char[20];
        char *candidateName = new char[20];
        char *DOB = new char[20];
        char *electionName = new char[20];
        char *partyName = new char[20];
        char *district = new char[20];
        char *constituency = new char[20];
        char *address = new char[30];
        char *phoneNo = new char[20];
        char *emailID = new char[20];
	char *subStr = new char[5];
	char *candidateName2 = new char[20];
	//cout << "Enter Candidate ID : ";
	//cin >> candidateID;
	cout << "Enter Candidate first Name : ";
	cin >> candidateName;
	cout << "Enter Date of Birth(DD-MM-YYYY) : ";
	cin >> DOB;
	cout << "Enter Election Name : ";
	cin >> electionName;
	cout << "Enter Party Name : ";
	cin >> partyName;
	cout << "Enter District : ";
	cin >> district;
	cout << "Enter Constituency : ";
	cin >> constituency;
	cout << "Enter Address : ";
	cin >> address;
	cout << "Enter Mobile Number : ";
	cin >> phoneNo;
	cout << "Enter Email ID : ";
	cin >> emailID;
	strncpy(subStr, phoneNo, 5);
	strcpy(candidateName2, candidateName);
	strcat(candidateName2,subStr);
	strcpy(candidateID, candidateName2);	
	ofstream write;
	write.open("../resources/CandidateData.txt",ios::app);
	if(write.is_open())
	{
		write << candidateID<<"\t"<< candidateName <<"\t"<< DOB <<"\t"<< electionName <<"\t"<< partyName <<"\t"<< district <<"\t"<< constituency <<"\t"<< address <<"\t"<< phoneNo <<"\t"<< emailID <<"\n";
		cout << "************************ CANDIDATE DETAILS ADDED SUCCESSFULLY ******************************\n";
	}
	write.close();
}

void Candidate :: viewCandidateDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                           Candidate Details                                                 \n";
        cout << "=============================================================================================================\n";
	char *candidateID = new char[20];
        char *candidateName = new char[20];
        char *DOB = new char[20];
        char *electionName = new char[20];
        char *partyName = new char[20];
        char *district = new char[20];
        char *constituency = new char[20];
        char *address = new char[20];
        char *phoneNo = new char[20];
        char *emailID = new char[20];
	ifstream read;
	read.open("../resources/CandidateData.txt");
	if(read.is_open())
	{
		while(read >> candidateID >> candidateName >> DOB >> electionName >> partyName >> district >> constituency >> address >> phoneNo >> emailID)
		{
			cout << candidateID <<"\t"<< candidateName <<"\t"<< DOB <<"\t"<< electionName <<"\t"<< partyName <<"\t"<< district <<"\t"<< constituency <<"\t"<< address <<"\t"<< phoneNo <<"\t"<< emailID <<"\n";
		}
	}
	read.close();
}

void Candidate :: updateCandidateDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                       Updating Candidate Details                                            \n";
        cout << "=============================================================================================================\n";
	int candidateStatus=0,cS=-1;
	char *candidateID = new char[20];
	char *eCandidateID = new char[20];
        char *candidateName = new char[20];
        char *DOB = new char[20];
        char *electionName = new char[20];
        char *partyName = new char[20];
        char *district = new char[20];
        char *constituency = new char[20];
        char *address = new char[20];
        char *phoneNo = new char[20];
        char *emailID = new char[20];
	cout << "Enter Candidate ID to Update : ";
	cin >> eCandidateID;
	ifstream read;
	ofstream write;
        read.open("../resources/CandidateData.txt");
        if(read.is_open())
        {
                while(read >> candidateID >> candidateName >> DOB >> electionName >> partyName >> district >> constituency >> address >> phoneNo >> emailID)
                {
			cS = strcmp(candidateID, eCandidateID);
			if(cS == 0)
			{
				candidateStatus = 1;
				break;
			}
		}
	}
	read.close();
	if(candidateStatus == 1)
	{
		char *uCandidateID = new char[20];
		char *uCandidateName = new char[20];
        	char *UDOB = new char[20];
        	char *uElectionName = new char[20];
        	char *uPartyName = new char[20];
        	char *uDistrict = new char[20];
        	char *uConstituency = new char[20];
        	char *uAddress = new char[30];
        	char *uPhoneNo = new char[20];
        	char *uEmailID = new char[20];
		cout << "Enter Updated Candidate ID : ";
        	cin >> uCandidateID;
        	cout << "Enter Updated Candidate Name : ";
        	cin >> uCandidateName;
        	cout << "Enter Updated Date of Birth : ";
        	cin >> UDOB;
        	cout << "Enter Updated Election Name : ";
        	cin >> uElectionName;
        	cout << "Enter Updated Party Name : ";
        	cin >> uPartyName;
        	cout << "Enter Updated District : ";
        	cin >> uDistrict;
        	cout << "Enter Updated Constituency : ";
        	cin >> uConstituency;
        	cout << "Enter Updated Address(Use comma instead of space) : ";
        	cin >> uAddress;
        	cout << "Enter Updated Mobile Number : ";
        	cin >> uPhoneNo;
        	cout << "Enter Updated Email ID : ";
        	cin >> uEmailID;
		read.open("../resources/CandidateData.txt");
		write.open("../resources/CandidateDataTemp.txt",ios::app);
		if(read.is_open())
		{
			while(read >> candidateID >> candidateName >> DOB >> electionName >> partyName >> district >> constituency >> address >> phoneNo >> emailID)
                	{
                        	cS = strcmp(candidateID, eCandidateID);
                        	if(cS == 0)
                        	{
                                	write << uCandidateID <<"\t"<< uCandidateName <<"\t"<< UDOB <<"\t"<< uElectionName <<"\t"<< uPartyName <<"\t"<< uDistrict <<"\t"<< uConstituency <<"\t"<< uAddress <<"\t"<< uPhoneNo <<"\t"<< uEmailID <<"\n";

                        	}
				else
				{
					write << candidateID <<"\t"<< candidateName <<"\t"<< DOB <<"\t"<< electionName <<"\t"<< partyName <<"\t"<< district <<"\t"<< constituency <<"\t"<< address <<"\t"<< phoneNo <<"\t"<< emailID <<"\n";

				}
                	}	
			read.close();
			write.close();
			remove("../resources/CandidateData.txt");
			rename("../resources/CandidateDataTemp.txt","../resources/CandidateData.txt");
			cout << "************************ CANDIDATE DETAILS UPDATED SUCCESSFULLY ******************************\n";
		}
		else
			cout << "cant open file\n";
		
	}
	else
		cout << "Candidate details are not found to update\n";
}
void Candidate :: deleteCandidateDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                       Deleting Candidate Details                                            \n";
        cout << "=============================================================================================================\n";
	int candidateStatus=0,cS=-1;
        char *candidateID = new char[20];
        char *eCandidateID = new char[20];
        char *candidateName = new char[20];
        char *DOB = new char[20];
        char *electionName = new char[20];
        char *partyName = new char[20];
        char *district = new char[20];
        char *constituency = new char[20];
        char *address = new char[20];
        char *phoneNo = new char[20];
        char *emailID = new char[20];
	cout << "Enter Candidate ID to Delete : ";
        cin >> eCandidateID;
        ifstream read;
        ofstream write;
        read.open("../resources/CandidateData.txt");
        if(read.is_open())
        {
                while(read >> candidateID >> candidateName >> DOB >> electionName >> partyName >> district >> constituency >> address >> phoneNo >> emailID)
                {
                        cS = strcmp(candidateID, eCandidateID);
                        if(cS == 0)
                        {
                                candidateStatus = 1;
                                break;
                        }
                }
        }
        read.close();
        if(candidateStatus == 1)
	{
		read.open("../resources/CandidateData.txt");
		write.open("../resources/CandidateDataTemp.txt",ios::app);
                while(read >> candidateID >> candidateName >> DOB >> electionName >> partyName >> district >> constituency >> address >> phoneNo >> emailID)
                {
                        cS = strcmp(candidateID, eCandidateID);
                        if(cS != 0)
                        {
                                write << candidateID <<"\t"<< candidateName <<"\t"<< DOB <<"\t"<< electionName <<"\t"<< partyName <<"\t"<< district <<"\t"<< constituency <<"\t"<< address <<"\t"<< phoneNo <<"\t"<< emailID <<"\n";

                        }
                }
		read.close();
		write.close();
		remove("../resources/CandidateData.txt");
                rename("../resources/CandidateDataTemp.txt","../resources/CandidateData.txt");
		cout << "************************ CANDIDATE DETAILS DELETED SUCCESSFULLY ******************************\n";
        }

}
