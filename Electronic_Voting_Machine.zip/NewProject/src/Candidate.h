class Candidate
{

	public:
		int candidateStatus,cS;
		char *candidateID;
                char *candidateName;
                char *DOB;
                char *electionName;
                char *partyName, *district, *constituency, *address, *phoneNo, *emailID;
              	char *uCandidateID;
		char *eCandidateID;
                char *uCandidateName;
                char *UDOB;
                char *uElectionName;
                char *uPartyName, *uDistrict, *uConstituency, *uAddress, *uPhoneNo, *uEmailID;
		void addCandidateDetails();
		void viewCandidateDetails();
		void updateCandidateDetails();
		void deleteCandidateDetails();

};
