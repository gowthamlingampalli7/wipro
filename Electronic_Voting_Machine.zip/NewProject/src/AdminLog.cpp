#include "AdminLog.h"
#include<iostream>
#include<cstring>
#include<cctype>
using namespace std;

int AdminLog :: adminLogin()
{
	system("clear");
	cout << "========================================================================================\n";
	cout << "				    Administrator Login	              			 \n";
	cout << "========================================================================================\n";
	int status=0,a,p,count=0,check;
	char * uName = new char[10];
	char * pwd = new char[10];
	char * userName=new char[10];//"admin";
	char * password=new char[10];//"admin@123";
	strcpy(userName,"admin");
	strcpy(password,"admin@123");
	cout << "Enter User Name : ";
	cin >> uName;
	cout << "Enter Password : ";
	cin >> pwd;
	a = strcmp(uName,userName);
        p = strcmp(password,pwd);
	if(a == 0 && p == 0)
	{
		status=1;
		cout << "************************ ADMINISTRATOR LOGIN SUCCESSFULLY ******************************\n";
	}
	return status;

}
