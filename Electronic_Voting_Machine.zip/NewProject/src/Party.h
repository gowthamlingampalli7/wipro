


class Party
{
	

	public:
		char *partyName;
		char *leaderName;
		char *partySymbol;
		char *uPartyName;
		char *uLeaderName;
		char *uPartySymbol;
		char *ePartyName;
		void addPartyDetails();
		void viewPartyDetails();
		void updatePartyDetails();
		void deletePartyDetails();

};
