#include<iostream>
#include<fstream>
#include "Election.h"
using namespace std;


void Election :: addElectionDetails()
{
		system("clear");
		cout << "=============================================================================================================\n";
        	cout << "                                       Adding Election Details                                               \n";
        	cout << "=============================================================================================================\n";
		char *electionName = new char[20];
		char *electionDate = new char[20];
		char *votingTime = new char[15];
		char *district = new char[20];
		char *constituency = new char[20];
		cout << "Enter Election Name(Assembly/ Muncipal/ Sarpanch) : ";
		cin >> electionName;
		cout << "Enter Election Date(DD-MM-YYYY) : ";
		cin >> electionDate;
		cout << "Enter District Name : ";
		cin >> district;
		cout << "Enter Constituency : ";
		cin >> constituency;
		strcpy(votingTime,"8AM-5PM");
		ofstream write;
		write.open("../resources/ElectionData.txt",ios::app);
		if(write.is_open())
		{
			write << electionName <<"\t"<< electionDate <<"\t"<< votingTime <<"\t"<< district <<"\t"<< constituency <<"\n";
			cout << "************************ ELECTION DETAILS ADDED SUCCESSFULLY ******************************\n";
		}
		write.close();

}


void Election :: viewElectionDetails()
{
	system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                       Election Details                                                      \n";
        cout << "=============================================================================================================\n";
	char *electionName = new char[20];
        char *electionDate = new char[20];
        char *votingTime = new char[15];
        char *district = new char[20];
        char *constituency = new char[20];
	ifstream read;
	read.open("../resources/ElectionData.txt");
	if(read.is_open())
	{
		while(read >> electionName >> electionDate >> votingTime >> district >> constituency)
		{
			cout << electionName <<"\t"<< electionDate <<"\t"<< votingTime <<"\t"<< district <<"\t"<< constituency<<"\n";
		}
	}
	read.close();
}

void Election :: updateElectionDetails()
{
        	system("clear");
        	cout << "=============================================================================================================\n";
        	cout << "                                     Update Election Details                                                 \n";
        	cout << "=============================================================================================================\n";
		int es = -1, eds = -1, electionStatus = 0;
		char *eElectionName = new char[20];
                char *eElectionDate = new char[20];
		char *electionName = new char[20];
                char *electionDate = new char[20];
                char *votingTime = new char[15];
                char *district = new char[20];
                char *constituency = new char[20];
		cout << "Enter Election Name to Update(Assembly/ Muncipal/ Sarpanch) : ";
                cin >> eElectionName;
                cout << "Enter Date of Election to Update(DD-MM-YYYY) : ";
                cin >> eElectionDate;
		ifstream read;
		ofstream write;
		read.open("../resources/ElectionData.txt");
		if(read.is_open())
		{
			//cout<<"...\n";
			while(read >> electionName >> electionDate >> votingTime >> district >> constituency)
			{
				//cout<<"'"<<electionName<<eElectionName<<electionDate<<eElectionDate<<"'\n";
				es = strcmp(electionName, eElectionName);
				eds = strcmp(electionDate, eElectionDate);
				//cout << eds<<endl;
				//cout << es<<endl;
				if(eds == 0 && es == 0)
				{
					electionStatus = 1;
					break;
				}
			}
		}
		read.close();
		if(electionStatus == 1)
		{
			char *uElectionName = new char[20];
                	char *uElectionDate = new char[20];
                	char *votingTime = new char[15];
                	char *uDistrict = new char[20];
                	char *uConstituency = new char[20];
                	cout << "Enter Updated Election Name(Assembly/ Muncipal/ Sarpanch) : ";
                	cin >> uElectionName;
                	cout << "Enter Updated Election Date(DD-MM-YYYY) : ";
                	cin >> uElectionDate;
                	cout << "Enter updated District Name : ";
                	cin >> uDistrict;
                	cout << "Enter updated Constituency : ";
                	cin >> uConstituency;
                	strcpy(votingTime,"8AM-5PM");
                	ofstream write;
                	read.open("../resources/ElectionData.txt");
			write.open("../resources/ElectionDataTemp.txt",ios::app);
                	if(write.is_open())
                	{
				while(read >> electionName >> electionDate >> votingTime >> district >> constituency)
				{
					es = strcmp(electionName, eElectionName);
	                                eds = strcmp(electionDate, eElectionDate);
        	                        if(eds == 0 && es == 0)
                	                {
                		        	write << uElectionName <<"\t"<< uElectionDate <<"\t"<< votingTime <<"\t"<< uDistrict <<"\t"<< uConstituency <<"\n";
                			}
					else
					{
						write << electionName <<"\t"<< electionDate <<"\t"<< votingTime <<"\t"<< district <<"\t"<< constituency <<"\n";
					}
				}
			}
			read.close();
                	write.close();
			remove("../resources/ElectionData.txt");
                	rename("../resources/ElectionDataTemp.txt","../resources/ElectionData.txt");
			cout << "************************ ELECTION DETAILS UPDATED SUCCESSFULLY ******************************\n";
		}
		else
		{
			cout << "Election Details are not available to update\n";
		}
}	

void Election :: deleteElectionDetails()
{
	        system("clear");
        	cout << "=============================================================================================================\n";
        	cout << "                                    Deleting Election Detail                                                 \n";
        	cout << "=============================================================================================================\n";
		int es = -1, eds = -1, electionStatus = 0;
                char *eElectionName = new char[20];
                char *eElectionDate = new char[20];
                char *electionName = new char[20];
                char *electionDate = new char[20];
                char *votingTime = new char[15];
                char *district = new char[20];
                char *constituency = new char[20];
                cout << "Enter Election Name to Delete(Assembly/ Muncipal/ Sarpanch) : ";
                cin >> eElectionName;
                cout << "Enter Date of Election to Delete(DD-MM-YYYY) : ";
                cin >> eElectionDate;
                ifstream read;
                ofstream write;
                read.open("../resources/ElectionData.txt");
                if(read.is_open())
                {
                        //cout<<"...\n";
                        while(read >> electionName >> electionDate >> votingTime >> district >> constituency)
                        {
                                //cout<<"'"<<electionName<<eElectionName<<electionDate<<eElectionDate<<"'\n";
                                es = strcmp(electionName, eElectionName);
                                eds = strcmp(electionDate, eElectionDate);
				//cout << es<<"," << eds<<endl;
                                if(eds == 0 && es == 0)
                                {
                                        electionStatus = 1;
					//cout << "found\n";
                                        break;
                                }
                        }
                }
                read.close();
                if(electionStatus == 1)
                {
			cout<<"hello\n";
			read.open("../resources/ElectionData.txt");
                	write.open("../resources/ElectionDataTemp.txt");
			if(read.is_open() && write.is_open())
			{
				 while(read >> electionName >> electionDate >> votingTime >> district >> constituency)
                                {
                                        es = strcmp(electionName, eElectionName);
                                        eds = strcmp(electionDate, eElectionDate);
                                        if(eds != 0 || es != 0)
                                        {
						cout <<"exe\n";
						write << electionName <<"\t"<< electionDate <<"\t"<< votingTime <<"\t"<< district <<"\t"<< constituency <<"\n";
					}
				}
				read.close();
                		write.close();
                		remove("../resources/ElectionData.txt");
                		rename("../resources/ElectionDataTemp.txt","../resources/ElectionData.txt");
				cout << "************************ ELECTION DETAILS DELETED SUCCESSFULLY ******************************\n";
			}
			else
				cout << "file cant open\n";
		}
		else
			cout << "Election Data is not available to delete\n";
			
}


void Election :: electionResult()
{
        system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                       Election Result                                                      \n";
        cout << "=============================================================================================================\n";
	char *electionName = new char[20];
	char *electionDate = new char[10];
	char *resultDate = new char[10];
	char *electionWinner = new char[20];
	ifstream read;
	read.open("../resources/ElectionResultData.txt");
	if(read.is_open())
	{
		while(read >> electionName >> electionDate >> resultDate >> electionWinner)
		{
			cout << electionName <<"\t"<<electionDate <<"\t"<< resultDate <<"\t"<< electionWinner <<"\n";
		}
	}
	else
		cout << "Election Data cant be shown\n";
	read.close();
}

void Election :: voterRequests()
{
        system("clear");
        cout << "=============================================================================================================\n";
        cout << "                                         Voter Requests                                                      \n";
        cout << "=============================================================================================================\n";
	char *voterName = new char[20];
	char *voterDob = new char[15];
	char *voterMobileNo = new char[15];
	char *voterAddress = new char[30];
	ifstream read;
	read.open("../resources/VoterRequestData.txt");
	if(read.is_open())
	{
		while(read >> voterName >> voterDob >> voterMobileNo >> voterAddress)
		{
			cout << voterName <<"\t"<< voterDob <<"\t"<< voterMobileNo <<"\t"<< voterAddress<<"\n";
		}
	}
	else
		cout << "Voter data cant be shown\n";
	read.close();
}

