#include<iostream>
#include "AdminLog.cpp"
#include "Election.cpp"
#include "Party.cpp"
#include "Candidate.cpp"
using namespace std;



int main()
{
	system("clear");
	cout << "=======================================================================================================\n";
	cout << " 			        WELCOME TO ELECTRONIC VOTING SYSTEM					\n";
	cout << "=======================================================================================================\n";	
	AdminLog *adminLog = new AdminLog;
	Election *election = new Election;
	Party *party = new Party;
	Candidate *candidate = new Candidate;
	int adminLoginStatus=0;
	cout << "Electronic Voting System\n";
	char choice, adminContinue='N', adminChoice,electionChoice,partyChoice,candidateChoice;
	choice_label:
	cout <<"1 - Administrator\n2 - Electoral Officer\n3 - Voter\n4 - Exit\nEnter Choice : ";
	cin >> choice;
	//choice_label:
	switch(choice)
	{
		case '1' :
		{
			adminLoginStatus = adminLog->adminLogin();
			if(adminLoginStatus == 1)
			{ 
				system("clear");
		        	cout << "=======================================================================================================\n";
        			cout << "                                    ADMINISTRATOR MODULE                                               \n";
        			cout << "=======================================================================================================\n";
			do
        		{
                		cout << "1 - Election Details\n2 - Party Details\n3 - Candidate Details\n4 - Voter Requests and Approvals\n5 - View Election Result\nEnter Choice : ";
				cin >> adminChoice;
				switch(adminChoice)
				{
				
					case '1':
					{
						cout << "Election details\n";
						cout << "1 - Add Election Details\n2 - Update Election Details\n3 - Delete Election Details\n4 - View Election Details\nEnter choice : ";
						cin >> electionChoice;
						switch(electionChoice)
						{
							case '1' :
							{
								//cout << "Add Election\n";
								election -> addElectionDetails();
								break;
							}
							case '2' :
                                                        {
                                                                //cout << "Update Election\n";
								election -> updateElectionDetails();
                                                                break;
                                                        }
							case '3' :
                                                        {
                                                                //cout << "Delete Election\n";
								election -> deleteElectionDetails();
                                                                break;
                                                        }
							case '4' :
                                                        {
                                                                //cout << "View Election\n";
								election -> viewElectionDetails();
                                                                break;
                                                        }
							default :
								cout << "Invalid Choice\n";
								break;
						}
						break;
					}
					case '2':
					{
						cout << "Party details\n";
						cout << "1 - Add Party Details\n2 - Update Party Details\n3 - Delete Party Details\n4 - View Party Details\nEnter choice : ";
                                                cin >> partyChoice;
                                                switch(partyChoice)
                                                {
                                                        case '1' :
                                                        {
                                                                //cout << "Add Party\n";
								party -> addPartyDetails();
                                                                break;
                                                        }
                                                        case '2' :
                                                        {
                                                                //cout << "Update Party\n";
								party -> updatePartyDetails();
                                                                break;
                                                        }
                                                        case '3' :
                                                        {
                                                                //cout << "Delete Party\n";
								party -> deletePartyDetails();
                                                                break;
                                                        }
                                                        case '4' :
                                                        {
                                                                //cout << "View Party\n";
								party -> viewPartyDetails();
                                                                break;
                                                        }
                                                        default :
                                                                cout << "Invalid Choice\n";
								break;
                                                }
						break;
					}
					case '3':
					{
						cout <<"Candidate details\n";
						cout << "1 - Add Candidate Details\n2 - Update Candidate Details\n3 - Delete Candidate Details\n4 - View Candidate Details\nEnter choice : ";
                                                cin >> candidateChoice;
                                                switch(candidateChoice)
                                                {
                                                        case '1' :
                                                        {
                                                                //cout << "Add Candidate\n";
								candidate -> addCandidateDetails();
                                                                break;
                                                        }
                                                        case '2' :
                                                        {
                                                                //cout << "Update Candidate\n";
								candidate -> updateCandidateDetails();
                                                                break;
                                                        }
                                                        case '3' :
                                                        {
                                                                //cout << "Delete Candidate\n";
								candidate -> deleteCandidateDetails();
                                                                break;
                                                        }
                                                        case '4' :
                                                        {
                                                                //cout << "View Candidate\n";
								candidate -> viewCandidateDetails();
                                                                break;
                                                        }
                                                        default :
                                                                cout << "Invalid Choice\n";
								break;
                                                }
						break;
					}
					case '4':
					{
						//cout << " Requests for IDs\n";
						election -> voterRequests();
						break;
					}
					case '5':
					{
						//cout << "election result\n";
						election -> electionResult();
						break;
					}
				}
				cout << "Do You Want to Continue as Administrator?? if Yes Enter 'Y' else Enter 'N' : ";
				cin >> adminContinue;
				if(adminContinue == 'N')
					adminLoginStatus = 0;
			}while(adminContinue!='N');
			}
			else
			{
				cout << "Invalid Credentials\n";
				//adminLoginStatus = adminLog -> adminLogin();
			}
			goto choice_label;
			
			
			
		}
		case '2' :
			cout << "Access Restricted for Electoral Officer\n";
			goto choice_label;
			
			
		case '3' :
			cout << "Access Restricted for Voter\n";
			goto choice_label;
			
		case '4' :
			exit(0);
			
		default	:
			cout<<"Invalid Choice\n";
			goto choice_label;
			
	}
	return 0;
}
