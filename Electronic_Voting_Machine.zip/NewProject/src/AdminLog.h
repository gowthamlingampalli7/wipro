class AdminLog
{
	private:
		char* userName, password;
	public:
		int adminLogin();
		int adminLogout();

};
